-- PostgreSQL DDL Schema for AssetFlow Management

-- Enable UUID extension if not already enabled
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Custom Function to map GENERATE_UUID() to uuid_generate_v4()
-- This ensures the Python query insert statements (e.g. GENERATE_UUID()) run unmodified.
CREATE OR REPLACE FUNCTION GENERATE_UUID()
RETURNS UUID AS $$
BEGIN
    RETURN uuid_generate_v4();
END;
$$ LANGUAGE plpgsql;

-- Enums
CREATE TYPE employee_role AS ENUM ('ADMIN', 'EMPLOYEE', 'AUDITOR', 'DEPARTMENT_HEAD');
CREATE TYPE asset_status AS ENUM ('AVAILABLE', 'ALLOCATED', 'UNDER_MAINTENANCE', 'LOST', 'RETIRED');
-- Note: Odoo uses lowercase values, we define VARCHAR compatibility or custom cast to allow upper/lower case.
-- We will use VARCHAR for status and role fields to remain robust, or we can use VARCHAR with CHECK constraints.
-- Let's use VARCHAR with CHECK constraints to be highly robust and compatible with different databases.

-- 1. Departments Table
CREATE TABLE departments (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    manager_id VARCHAR(36), -- FK to employees (added via ALTER below to prevent cyclic reference errors)
    parent_id VARCHAR(36),
    FOREIGN KEY (parent_id) REFERENCES departments(id) ON DELETE SET NULL
);

-- 2. Employees Table
CREATE TABLE employees (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(50) NOT NULL DEFAULT 'EMPLOYEE',
    department_id VARCHAR(36),
    FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL,
    CONSTRAINT chk_employee_role CHECK (role IN ('ADMIN', 'EMPLOYEE', 'AUDITOR', 'DEPARTMENT_HEAD'))
);

-- Alter departments to add manager_id FK constraint now that employees table is defined
ALTER TABLE departments 
ADD CONSTRAINT fk_departments_manager 
FOREIGN KEY (manager_id) REFERENCES employees(id) ON DELETE SET NULL;

-- 3. Asset Categories Table
CREATE TABLE asset_categories (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(255) NOT NULL UNIQUE,
    custom_fields JSONB -- Stores flexible dynamic attributes (e.g. warranty, specification)
);

-- 4. Assets Table
CREATE TABLE assets (
    id VARCHAR(36) PRIMARY KEY,
    asset_tag VARCHAR(100) UNIQUE NOT NULL,
    category_id VARCHAR(36) NOT NULL,
    current_holder_id VARCHAR(36),
    assigned_department_id VARCHAR(36),
    status VARCHAR(50) NOT NULL DEFAULT 'AVAILABLE',
    is_bookable BOOLEAN NOT NULL DEFAULT FALSE,
    FOREIGN KEY (category_id) REFERENCES asset_categories(id) ON DELETE RESTRICT,
    FOREIGN KEY (current_holder_id) REFERENCES employees(id) ON DELETE SET NULL,
    FOREIGN KEY (assigned_department_id) REFERENCES departments(id) ON DELETE SET NULL,
    CONSTRAINT chk_asset_status CHECK (status IN ('AVAILABLE', 'ALLOCATED', 'UNDER_MAINTENANCE', 'LOST', 'RETIRED'))
);

-- 5. Asset Reservations Table
CREATE TABLE asset_reservations (
    id VARCHAR(36) PRIMARY KEY,
    asset_id VARCHAR(36) NOT NULL,
    reserved_by_id VARCHAR(36) NOT NULL,
    start_time TIMESTAMP WITH TIME ZONE NOT NULL,
    end_time TIMESTAMP WITH TIME ZONE NOT NULL,
    purpose TEXT NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'CONFIRMED',
    FOREIGN KEY (asset_id) REFERENCES assets(id) ON DELETE CASCADE,
    FOREIGN KEY (reserved_by_id) REFERENCES employees(id) ON DELETE CASCADE,
    CONSTRAINT chk_reservation_times CHECK (start_time < end_time),
    CONSTRAINT chk_reservation_status CHECK (status IN ('CONFIRMED', 'CANCELLED', 'COMPLETED'))
);

-- Indexes for overlapping reservations checks (performance)
CREATE INDEX idx_reservations_asset_status ON asset_reservations(asset_id, status);
CREATE INDEX idx_reservations_time_range ON asset_reservations(start_time, end_time);

-- 6. Asset Transfers Table
CREATE TABLE asset_transfers (
    id VARCHAR(36) PRIMARY KEY,
    asset_id VARCHAR(36) NOT NULL,
    from_user_id VARCHAR(36) NOT NULL,
    to_user_id VARCHAR(36) NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'PENDING',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    FOREIGN KEY (asset_id) REFERENCES assets(id) ON DELETE CASCADE,
    FOREIGN KEY (from_user_id) REFERENCES employees(id) ON DELETE CASCADE,
    FOREIGN KEY (to_user_id) REFERENCES employees(id) ON DELETE CASCADE,
    CONSTRAINT chk_transfer_status CHECK (status IN ('PENDING', 'APPROVED', 'REJECTED'))
);

-- 7. Audit Logs Table
CREATE TABLE audit_logs (
    id VARCHAR(36) PRIMARY KEY,
    asset_id VARCHAR(36) NOT NULL,
    auditor_id VARCHAR(36) NOT NULL,
    status_flag VARCHAR(50) NOT NULL,
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    FOREIGN KEY (asset_id) REFERENCES assets(id) ON DELETE CASCADE,
    FOREIGN KEY (auditor_id) REFERENCES employees(id) ON DELETE CASCADE,
    CONSTRAINT chk_audit_status_flag CHECK (status_flag IN ('MISSING', 'DAMAGED', 'UNAUTHORIZED_HOLDER'))
);
