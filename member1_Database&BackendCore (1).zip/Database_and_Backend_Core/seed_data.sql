-- Seed Data for AssetFlow Management Database

-- 1. Insert Departments
-- Top-level departments
INSERT INTO departments (id, name, manager_id, parent_id)
VALUES 
    ('d1111111-1111-1111-1111-111111111111', 'Executive Board', NULL, NULL),
    ('d2222222-2222-2222-2222-222222222222', 'Human Resources', NULL, NULL);

-- Sub-departments
INSERT INTO departments (id, name, manager_id, parent_id)
VALUES 
    ('d3333333-3333-3333-3333-333333333333', 'Engineering Department', NULL, 'd1111111-1111-1111-1111-111111111111'),
    ('d4444444-4444-4444-4444-444444444444', 'Marketing Department', NULL, 'd1111111-1111-1111-1111-111111111111');

-- 2. Insert Employees
-- Password hashes here are simple placeholders (e.g., bcrypt hashes)
INSERT INTO employees (id, name, email, password_hash, role, department_id)
VALUES
    ('e1111111-1111-1111-1111-111111111111', 'Alice CEO', 'ceo@company.com', '$2b$12$KIX4FpT3pBf...', 'ADMIN', 'd1111111-1111-1111-1111-111111111111'),
    ('e2222222-2222-2222-2222-222222222222', 'Bob HR-Manager', 'hr@company.com', '$2b$12$KIX4FpT3pBf...', 'DEPARTMENT_HEAD', 'd2222222-2222-2222-2222-222222222222'),
    ('e3333333-3333-3333-3333-333333333333', 'Charlie Tech-Lead', 'charlie@company.com', '$2b$12$KIX4FpT3pBf...', 'EMPLOYEE', 'd3333333-3333-3333-3333-333333333333'),
    ('e4444444-4444-4444-4444-444444444444', 'Daniel Auditor', 'audit@company.com', '$2b$12$KIX4FpT3pBf...', 'AUDITOR', 'd1111111-1111-1111-1111-111111111111'),
    ('e5555555-5555-5555-5555-555555555555', 'Emma Engineer', 'emma@company.com', '$2b$12$KIX4FpT3pBf...', 'EMPLOYEE', 'd3333333-3333-3333-3333-333333333333');

-- Update department managers now that employees are inserted
UPDATE departments SET manager_id = 'e1111111-1111-1111-1111-111111111111' WHERE id = 'd1111111-1111-1111-1111-111111111111';
UPDATE departments SET manager_id = 'e2222222-2222-2222-2222-222222222222' WHERE id = 'd2222222-2222-2222-2222-222222222222';
UPDATE departments SET manager_id = 'e3333333-3333-3333-3333-333333333333' WHERE id = 'd3333333-3333-3333-3333-333333333333';

-- 3. Insert Asset Categories
INSERT INTO asset_categories (id, name, custom_fields)
VALUES
    ('c1111111-1111-1111-1111-111111111111', 'Laptops & Hardware', '{"device_type": "Laptop", "warranty_months": 24}'),
    ('c2222222-2222-2222-2222-222222222222', 'Conference Rooms', '{"capacity": 12, "projector_available": true}'),
    ('c3333333-3333-3333-3333-333333333333', 'Company Vehicles', '{"fuel_type": "Electric", "last_service": "2026-01-01"}');

-- 4. Insert Assets
INSERT INTO assets (id, asset_tag, category_id, current_holder_id, assigned_department_id, status, is_bookable)
VALUES
    -- Available laptops
    ('a1111111-1111-1111-1111-111111111111', 'AF-0001', 'c1111111-1111-1111-1111-111111111111', NULL, 'd3333333-3333-3333-3333-333333333333', 'AVAILABLE', FALSE),
    -- Allocated Laptop
    ('a2222222-2222-2222-2222-222222222222', 'AF-0002', 'c1111111-1111-1111-1111-111111111111', 'e3333333-3333-3333-3333-333333333333', 'd3333333-3333-3333-3333-333333333333', 'ALLOCATED', FALSE),
    -- Bookable conference room
    ('a3333333-3333-3333-3333-333333333333', 'AF-0003', 'c2222222-2222-2222-2222-222222222222', NULL, 'd1111111-1111-1111-1111-111111111111', 'AVAILABLE', TRUE),
    -- Under maintenance bookable electric car
    ('a4444444-4444-4444-4444-444444444444', 'AF-0004', 'c3333333-3333-3333-3333-333333333333', NULL, 'd1111111-1111-1111-1111-111111111111', 'UNDER_MAINTENANCE', TRUE);

-- 5. Insert Sample Reservations
INSERT INTO asset_reservations (id, asset_id, reserved_by_id, start_time, end_time, purpose, status)
VALUES
    ('r1111111-1111-1111-1111-111111111111', 'a3333333-3333-3333-3333-333333333333', 'e3333333-3333-3333-3333-333333333333', NOW() + INTERVAL '1 day', NOW() + INTERVAL '1 day 2 hours', 'Sprint Planning Meet', 'CONFIRMED');
