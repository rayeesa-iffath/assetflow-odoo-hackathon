import sqlite3
import os
import re
import uuid
from datetime import datetime, timedelta

def make_sqlite_compatible(postgres_ddl):
    statements = []
    for stmt in postgres_ddl.split(';'):
        # Strip comments
        lines = []
        for line in stmt.splitlines():
            line_clean = line.strip()
            if not line_clean.startswith('--'):
                lines.append(line)
        stmt_clean = '\n'.join(lines).strip()
        
        if not stmt_clean:
            continue
        
        # Keep only CREATE TABLE and CREATE INDEX for the SQLite setup
        if stmt_clean.upper().startswith('CREATE TABLE') or stmt_clean.upper().startswith('CREATE INDEX'):
            # Replace PostgreSQL types and functions with SQLite equivalents
            stmt_clean = stmt_clean.replace('JSONB', 'TEXT')
            stmt_clean = stmt_clean.replace('jsonb', 'text')
            stmt_clean = stmt_clean.replace('DEFAULT NOW()', 'DEFAULT CURRENT_TIMESTAMP')
            stmt_clean = stmt_clean.replace('default now()', 'default CURRENT_TIMESTAMP')
            stmt_clean = stmt_clean.replace('DEFAULT now()', 'DEFAULT CURRENT_TIMESTAMP')
            statements.append(stmt_clean)
            
    return ';\n'.join(statements)

def initialize_database():
    db_file = "assetflow.db"
    
    # Remove existing db file if any
    if os.path.exists(db_file):
        os.remove(db_file)
        
    print(f"Creating SQLite database file: {db_file}")
    conn = sqlite3.connect(db_file)
    conn.execute("PRAGMA foreign_keys = ON;")
    
    # Register custom PostgreSQL functions for SQLite connection
    conn.create_function("GENERATE_UUID", 0, lambda: str(uuid.uuid4()))
    conn.create_function("NOW", 0, lambda: datetime.now().isoformat())
    
    # 1. Read and load schema
    schema_path = "schema.sql"
    if not os.path.exists(schema_path):
        print(f"Error: {schema_path} not found!")
        return
        
    print(f"Reading schema from: {schema_path}")
    with open(schema_path, 'r', encoding='utf-8') as f:
        postgres_ddl = f.read()
        
    sqlite_ddl = make_sqlite_compatible(postgres_ddl)
    
    # Execute DDL
    cursor = conn.cursor()
    for stmt in sqlite_ddl.split(';'):
        stmt_clean = stmt.strip()
        if stmt_clean:
            cursor.execute(stmt_clean)
    conn.commit()
    print("Database tables and indexes created successfully.")
    
    # 2. Read and load seed data
    seed_path = "seed_data.sql"
    if not os.path.exists(seed_path):
        print(f"Error: {seed_path} not found!")
        return
        
    print(f"Reading seed data from: {seed_path}")
    with open(seed_path, 'r', encoding='utf-8') as f:
        seed_sql = f.read()
        
    # Replace interval calculations for SQLite compatibility
    tomorrow = (datetime.now() + timedelta(days=1)).strftime('%Y-%m-%d %H:%M:%S')
    tomorrow_plus_2h = (datetime.now() + timedelta(days=1, hours=2)).strftime('%Y-%m-%d %H:%M:%S')
    
    seed_sql = seed_sql.replace("NOW() + INTERVAL '1 day 2 hours'", f"'{tomorrow_plus_2h}'")
    seed_sql = seed_sql.replace("NOW() + INTERVAL '1 day'", f"'{tomorrow}'")
    
    # Execute seed inserts
    for stmt in seed_sql.split(';'):
        stmt_clean = stmt.strip()
        if stmt_clean:
            cursor.execute(stmt_clean)
    conn.commit()
    print("Seed data inserted successfully.")
    
    conn.close()
    print(f"\nSUCCESS: Database '{db_file}' is ready to use!")

if __name__ == "__main__":
    initialize_database()
