{
    'name': 'AssetFlow - Asset & Resource Management',
    'version': '17.0.1.0.0',
    'summary': 'Asset Registration, Allocation, Resource Booking & QR Search',
    'description': """
AssetFlow
=========
Core module implementing:
- Asset Registration & Directory (with auto-tag + QR)
- Asset Allocation & Transfer (with conflict blocking)
- Resource Booking (with overlap validation)
- Search/Filter across assets
""",
    'category': 'Operations',
    'author': 'AssetFlow Team',
    'depends': ['base', 'hr', 'mail'],
    'data': [
        'security/security.xml',
        'security/ir.model.access.csv',
        'data/ir_sequence_data.xml',
        'views/asset_category_views.xml',
        'views/asset_views.xml',
        'views/allocation_views.xml',
        'views/booking_views.xml',
        'views/menu_views.xml',
    ],
    'installable': True,
    'application': True,
    'license': 'LGPL-3',
}
