def record_audit_discrepancy(db_session, asset_id: str, auditor_id: str, found_status: str, notes: str):
    """
    Updates asset state and flags an audit discrepancy log.
    found_status choices: 'MISSING', 'DAMAGED', 'UNAUTHORIZED_HOLDER'
    """
    # Map findings to asset status
    status_map = {
        "MISSING": "LOST",
        "DAMAGED": "UNDER_MAINTENANCE",
        "UNAUTHORIZED_HOLDER": "ALLOCATED"
    }
    
    new_asset_status = status_map.get(found_status, "UNDER_MAINTENANCE")

    # Transaction: Update Asset + Log Audit
    db_session.execute(
        "UPDATE assets SET status = :status WHERE id = :asset_id",
        {"status": new_asset_status, "asset_id": asset_id}
    )

    db_session.execute("""
        INSERT INTO audit_logs (id, asset_id, auditor_id, status_flag, notes, created_at)
        VALUES (GENERATE_UUID(), :asset_id, :auditor_id, :found_status, :notes, NOW())
    """, {
        "asset_id": asset_id,
        "auditor_id": auditor_id,
        "found_status": found_status,
        "notes": notes
    })

    db_session.commit()
    return {"status": "Discrepancy logged successfully", "new_asset_status": new_asset_status}
