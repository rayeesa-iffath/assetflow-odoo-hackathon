from datetime import datetime
from typing import Dict, Any, Tuple

def validate_and_create_reservation(
    db_session, 
    asset_id: str, 
    user_id: str, 
    start_time: datetime, 
    end_time: datetime, 
    purpose: str
) -> Tuple[bool, Dict[str, Any], int]:
    """
    Validates availability and books a shared asset.
    Returns: (success_boolean, payload, http_status_code)
    """
    # 1. Verify asset exists and is bookable
    asset = db_session.query("SELECT is_bookable, status FROM assets WHERE id = :id", {"id": asset_id}).fetchone()
    if not asset:
        return False, {"error": "Asset not found"}, 404
        
    if not asset.is_bookable:
        return False, {"error": "This asset is not marked as bookable/shared resource"}, 400

    if asset.status == "UNDER_MAINTENANCE":
        return False, {"error": "Asset is currently under maintenance"}, 400

    # 2. Check for Overlapping Reservations
    overlap_query = """
        SELECT id, reserved_by_id, start_time, end_time 
        FROM asset_reservations
        WHERE asset_id = :asset_id
          AND status = 'CONFIRMED'
          AND start_time < :end_time 
          AND end_time > :start_time
        LIMIT 1;
    """
    existing_conflict = db_session.execute(overlap_query, {
        "asset_id": asset_id,
        "start_time": start_time,
        "end_time": end_time
    }).fetchone()

    if existing_conflict:
        return False, {
            "error": "Time slot conflict detected",
            "conflicting_reservation": {
                "id": existing_conflict.id,
                "reserved_by": existing_conflict.reserved_by_id,
                "start_time": existing_conflict.start_time.isoformat() if isinstance(existing_conflict.start_time, datetime) else existing_conflict.start_time,
                "end_time": existing_conflict.end_time.isoformat() if isinstance(existing_conflict.end_time, datetime) else existing_conflict.end_time
            }
        }, 409  # 409 Conflict

    # 3. Create Reservation if clean
    insert_query = """
        INSERT INTO asset_reservations (id, asset_id, reserved_by_id, start_time, end_time, purpose, status)
        VALUES (GENERATE_UUID(), :asset_id, :user_id, :start_time, :end_time, :purpose, 'CONFIRMED')
        RETURNING id;
    """
    new_res_id = db_session.execute(insert_query, {
        "asset_id": asset_id,
        "user_id": user_id,
        "start_time": start_time,
        "end_time": end_time,
        "purpose": purpose
    }).fetchone()[0]

    db_session.commit()

    return True, {
        "message": "Reservation confirmed",
        "reservation_id": new_res_id
    }, 201
