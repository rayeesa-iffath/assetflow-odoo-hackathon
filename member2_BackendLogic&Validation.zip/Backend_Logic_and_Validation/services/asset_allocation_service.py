from typing import Dict, Any, Tuple

def handle_asset_allocation_request(
    db_session, 
    asset_id: str, 
    requesting_user_id: str
) -> Tuple[bool, Dict[str, Any], int]:
    """
    Handles immediate direct allocation or auto-triggers a transfer request
    if the asset is currently allocated to someone else.
    """
    asset = db_session.query(
        "SELECT id, asset_tag, status, current_holder_id FROM assets WHERE id = :id",
        {"id": asset_id}
    ).fetchone()

    if not asset:
        return False, {"error": "Asset not found"}, 404

    # CASE A: Asset is Available -> Direct Allocation
    if asset.status == "AVAILABLE":
        update_query = """
            UPDATE assets 
            SET status = 'ALLOCATED', current_holder_id = :user_id 
            WHERE id = :asset_id;
        """
        db_session.execute(update_query, {"user_id": requesting_user_id, "asset_id": asset_id})
        db_session.commit()
        return True, {"message": "Asset allocated successfully", "asset_id": asset_id}, 200

    # CASE B: Asset is already Allocated -> Create Transfer Request
    elif asset.status == "ALLOCATED":
        if asset.current_holder_id == requesting_user_id:
            return False, {"error": "You already hold this asset"}, 400

        transfer_query = """
            INSERT INTO asset_transfers (id, asset_id, from_user_id, to_user_id, status)
            VALUES (GENERATE_UUID(), :asset_id, :from_user, :to_user, 'PENDING');
        """
        db_session.execute(transfer_query, {
            "asset_id": asset_id,
            "from_user": asset.current_holder_id,
            "to_user": requesting_user_id
        })
        db_session.commit()
        
        return True, {
            "message": "Asset is currently allocated. Transfer request sent to current holder.",
            "current_holder_id": asset.current_holder_id
        }, 202  # 202 Accepted

    # CASE C: Asset is Lost or Under Maintenance
    else:
        return False, {
            "error": f"Cannot allocate asset in state '{asset.status}'"
        }, 400
