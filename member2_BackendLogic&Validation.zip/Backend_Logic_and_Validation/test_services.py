import os
import sqlite3
import uuid
import re
from datetime import datetime, timedelta

from services.reservation_service import validate_and_create_reservation
from services.asset_allocation_service import handle_asset_allocation_request
from services.audit_service import record_audit_discrepancy

# Custom Row wrapper for attribute access (mocking SQLAlchemy row objects)
class MockRow:
    def __init__(self, description, row_tuple):
        self._keys = [col[0] for col in description] if description else []
        self._values = row_tuple if row_tuple else []
        
    def __getattr__(self, name):
        if name in self._keys:
            idx = self._keys.index(name)
            return self._values[idx]
        raise AttributeError(f"Row has no attribute '{name}'")
        
    def __getitem__(self, index):
        return self._values[index]

class MockQueryResult:
    def __init__(self, cursor):
        self.cursor = cursor
        
    def fetchone(self):
        row = self.cursor.fetchone()
        if row is None:
            return None
        return MockRow(self.cursor.description, row)

class MockDbSession:
    def __init__(self, conn):
        self.conn = conn
        
    def query(self, query_str, params=None):
        cursor = self.conn.cursor()
        cursor.execute(query_str, params or {})
        return MockQueryResult(cursor)
        
    def execute(self, query_str, params=None):
        cursor = self.conn.cursor()
        cursor.execute(query_str, params or {})
        return MockQueryResult(cursor)
        
    def commit(self):
        self.conn.commit()

def make_sqlite_compatible(postgres_ddl):
    # Only extract CREATE TABLE and CREATE INDEX statements, stripping out extensions, functions, types, and alter statements.
    statements = []
    # Split by semicolon to get individual commands
    for stmt in postgres_ddl.split(';'):
        # Strip comments
        lines = []
        for line in stmt.splitlines():
            line_clean = line.strip()
            if not line_clean.startswith('--'):
                lines.append(line)
        stmt_clean = '\n'.join(lines).strip()
        
        if not stmt_clean:
            continue
        
        # We only keep CREATE TABLE and CREATE INDEX for the SQLite simulation
        if stmt_clean.upper().startswith('CREATE TABLE') or stmt_clean.upper().startswith('CREATE INDEX'):
            # Replace PostgreSQL JSONB with TEXT
            stmt_clean = stmt_clean.replace('JSONB', 'TEXT')
            stmt_clean = stmt_clean.replace('jsonb', 'text')
            # Replace PostgreSQL NOW() default with SQLite CURRENT_TIMESTAMP
            stmt_clean = stmt_clean.replace('DEFAULT NOW()', 'DEFAULT CURRENT_TIMESTAMP')
            stmt_clean = stmt_clean.replace('default now()', 'default CURRENT_TIMESTAMP')
            stmt_clean = stmt_clean.replace('DEFAULT now()', 'DEFAULT CURRENT_TIMESTAMP')
            statements.append(stmt_clean)
            
    return ';\n'.join(statements)

def run_tests():
    # 1. Initialize SQLite Database
    conn = sqlite3.connect(":memory:", detect_types=sqlite3.PARSE_DECLTYPES)
    conn.execute("PRAGMA foreign_keys = ON;")
    
    # Register custom PostgreSQL functions for SQLite
    conn.create_function("GENERATE_UUID", 0, lambda: str(uuid.uuid4()))
    conn.create_function("NOW", 0, lambda: datetime.now().isoformat())
    
    # Read schema.sql
    schema_path = os.path.abspath(os.path.join(os.path.dirname(__file__), 'schema.sql'))
    print(f"Reading schema from: {schema_path}")
    with open(schema_path, 'r', encoding='utf-8') as f:
        postgres_ddl = f.read()
        
    sqlite_ddl = make_sqlite_compatible(postgres_ddl)
    
    # Run the SQL statements
    cursor = conn.cursor()
    sqlite_statements = sqlite_ddl.split(';')
    for stmt in sqlite_statements:
        stmt_clean = stmt.strip()
        if stmt_clean:
            try:
                cursor.execute(stmt_clean)
            except sqlite3.OperationalError as e:
                with open("failed_sql.txt", "w") as err_file:
                    err_file.write(f"ERROR: {str(e)}\n\nFAILED STATEMENT:\n{stmt_clean}")
                print(f"\n[ERROR] Failed to execute statement: written to failed_sql.txt\n")
                raise e
    conn.commit()
    print("Schema initialized successfully in simulated DB.")
    
    # Create DB Session wrapper
    db_session = MockDbSession(conn)
    
    # 2. Populate basic entities
    dept_id = str(uuid.uuid4())
    emp_id = str(uuid.uuid4())
    category_id = str(uuid.uuid4())
    asset_id = str(uuid.uuid4())
    bookable_asset_id = str(uuid.uuid4())
    
    # Insert Department
    cursor.execute(
        "INSERT INTO departments (id, name, manager_id, parent_id) VALUES (?, ?, NULL, NULL)",
        (dept_id, "Engineering")
    )
    
    # Insert Employee
    cursor.execute(
        "INSERT INTO employees (id, name, email, password_hash, role, department_id) VALUES (?, ?, ?, ?, ?, ?)",
        (emp_id, "Alice Smith", "alice@example.com", "hash", "EMPLOYEE", dept_id)
    )
    
    # Update Department manager
    cursor.execute(
        "UPDATE departments SET manager_id = ? WHERE id = ?",
        (emp_id, dept_id)
    )
    
    # Insert Asset Category
    cursor.execute(
        "INSERT INTO asset_categories (id, name, custom_fields) VALUES (?, ?, ?)",
        (category_id, "Hardware", '{"warranty": 12}')
    )
    
    # Insert Asset (Not Bookable, Available)
    cursor.execute(
        "INSERT INTO assets (id, asset_tag, category_id, current_holder_id, assigned_department_id, status, is_bookable) VALUES (?, ?, ?, NULL, ?, ?, ?)",
        (asset_id, "AF-0001", category_id, dept_id, "AVAILABLE", False)
    )
    
    # Insert Asset (Bookable, Available)
    cursor.execute(
        "INSERT INTO assets (id, asset_tag, category_id, current_holder_id, assigned_department_id, status, is_bookable) VALUES (?, ?, ?, NULL, ?, ?, ?)",
        (bookable_asset_id, "AF-0002", category_id, dept_id, "AVAILABLE", True)
    )
    
    conn.commit()
    print("Test fixtures populated.")
    
    # --- TEST 1: validate_and_create_reservation ---
    print("\n--- Running Test 1: validate_and_create_reservation ---")
    
    # Test 1A: Non-existent asset
    success, res, code = validate_and_create_reservation(
        db_session, "non-existent-id", emp_id, datetime.now(), datetime.now() + timedelta(hours=2), "Meeting"
    )
    assert not success and code == 404, f"Expected 404, got {code} ({res})"
    print("Test 1A (Asset Not Found) passed.")
    
    # Test 1B: Non-bookable asset
    success, res, code = validate_and_create_reservation(
        db_session, asset_id, emp_id, datetime.now(), datetime.now() + timedelta(hours=2), "Meeting"
    )
    assert not success and code == 400 and "not marked as bookable" in res["error"], f"Expected 400 bookable error, got {code} ({res})"
    print("Test 1B (Non-bookable blocking) passed.")
    
    # Test 1C: Successful reservation
    start = datetime.now() + timedelta(days=1)
    end = start + timedelta(hours=2)
    success, res, code = validate_and_create_reservation(
        db_session, bookable_asset_id, emp_id, start, end, "Sprint Planning"
    )
    assert success and code == 201, f"Expected 201, got {code} ({res})"
    reservation_id = res["reservation_id"]
    print(f"Test 1C (Successful booking) passed. Res ID: {reservation_id}")
    
    # Test 1D: Overlapping reservation overlap check
    success, res, code = validate_and_create_reservation(
        db_session, bookable_asset_id, emp_id, start + timedelta(minutes=30), end - timedelta(minutes=30), "Interfering Meet"
    )
    assert not success and code == 409, f"Expected 409 conflict, got {code} ({res})"
    print("Test 1D (Overlap detection) passed.")
    
    # --- TEST 2: handle_asset_allocation_request ---
    print("\n--- Running Test 2: handle_asset_allocation_request ---")
    
    # Test 2A: Direct Allocation
    success, res, code = handle_asset_allocation_request(db_session, asset_id, emp_id)
    assert success and code == 200, f"Expected 200, got {code} ({res})"
    
    # Check asset status changed to ALLOCATED and holder updated
    row = db_session.query("SELECT status, current_holder_id FROM assets WHERE id = :id", {"id": asset_id}).fetchone()
    assert row.status == "ALLOCATED" and row.current_holder_id == emp_id, "Asset status/holder check failed after allocation"
    print("Test 2A (Direct Allocation) passed.")
    
    # Test 2B: Already Allocated -> Transfer Request
    emp2_id = str(uuid.uuid4())
    cursor.execute(
        "INSERT INTO employees (id, name, email, password_hash, role, department_id) VALUES (?, ?, ?, ?, ?, ?)",
        (emp2_id, "Bob Johnson", "bob@example.com", "hash", "EMPLOYEE", dept_id)
    )
    conn.commit()
    
    success, res, code = handle_asset_allocation_request(db_session, asset_id, emp2_id)
    assert success and code == 202 and "Transfer request sent" in res["message"], f"Expected 202, got {code} ({res})"
    
    # Check transfer log created
    t_row = db_session.query("SELECT from_user_id, to_user_id, status FROM asset_transfers WHERE asset_id = :id", {"id": asset_id}).fetchone()
    assert t_row and t_row.from_user_id == emp_id and t_row.to_user_id == emp2_id and t_row.status == "PENDING", "Transfer request verification failed"
    print("Test 2B (Auto Transfer Request) passed.")
    
    # --- TEST 3: record_audit_discrepancy ---
    print("\n--- Running Test 3: record_audit_discrepancy ---")
    
    auditor_id = str(uuid.uuid4())
    cursor.execute(
        "INSERT INTO employees (id, name, email, password_hash, role, department_id) VALUES (?, ?, ?, ?, ?, ?)",
        (auditor_id, "Charlie Auditor", "charlie@example.com", "hash", "AUDITOR", dept_id)
    )
    conn.commit()
    
    res = record_audit_discrepancy(db_session, asset_id, auditor_id, "DAMAGED", "Screen cracked")
    assert res["new_asset_status"] == "UNDER_MAINTENANCE", f"Expected new status UNDER_MAINTENANCE, got {res}"
    
    # Check asset status in database
    row = db_session.query("SELECT status FROM assets WHERE id = :id", {"id": asset_id}).fetchone()
    assert row.status == "UNDER_MAINTENANCE", f"Expected status UNDER_MAINTENANCE in DB, got {row.status}"
    
    # Check audit log created
    log = db_session.query("SELECT status_flag, notes, auditor_id FROM audit_logs WHERE asset_id = :id", {"id": asset_id}).fetchone()
    assert log and log.status_flag == "DAMAGED" and log.notes == "Screen cracked" and log.auditor_id == auditor_id, "Audit log verification failed"
    print("Test 3 (Record Discrepancy) passed.")
    
    print("\n" + "="*40)
    print("ALL SERVICE FUNCTIONS & SQL QUERIES ARE WORKING PERFECTLY!")
    print("="*40)

if __name__ == "__main__":
    run_tests()
