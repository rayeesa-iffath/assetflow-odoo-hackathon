import sqlite3
import uuid
import sys
from datetime import datetime, timedelta

from services.reservation_service import validate_and_create_reservation
from services.asset_allocation_service import handle_asset_allocation_request
from services.audit_service import record_audit_discrepancy

# Custom Row wrapper for attribute access (mocking SQLAlchemy row objects)
class SQLiteRowWrapper:
    def __init__(self, description, row_tuple):
        self._keys = [col[0] for col in description] if description else []
        self._values = row_tuple if row_tuple else []
        
    def __getattr__(self, name):
        if name in self._keys:
            idx = self._keys.index(name)
            return self._values[idx]
        raise AttributeError(f"Row has no attribute '{name}'")
        
    def __getitem__(self, index):
        return self._values[index]

class SQLiteQueryResult:
    def __init__(self, cursor):
        self.cursor = cursor
        
    def fetchone(self):
        row = self.cursor.fetchone()
        if row is None:
            return None
        return SQLiteRowWrapper(self.cursor.description, row)

class SQLiteDbSession:
    def __init__(self, conn):
        self.conn = conn
        
    def query(self, query_str, params=None):
        cursor = self.conn.cursor()
        cursor.execute(query_str, params or {})
        return SQLiteQueryResult(cursor)
        
    def execute(self, query_str, params=None):
        cursor = self.conn.cursor()
        cursor.execute(query_str, params or {})
        return SQLiteQueryResult(cursor)
        
    def commit(self):
        self.conn.commit()

def run_demo():
    db_file = "assetflow.db"
    
    # Check if database exists
    import os
    if not os.path.exists(db_file):
        print(f"Error: {db_file} not found. Please run 'python init_db.py' first to initialize the database.")
        sys.exit(1)
        
    # Connect and register SQL custom functions
    conn = sqlite3.connect(db_file)
    conn.execute("PRAGMA foreign_keys = ON;")
    conn.create_function("GENERATE_UUID", 0, lambda: str(uuid.uuid4()))
    conn.create_function("NOW", 0, lambda: datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    
    # Wrap in session interface
    db_session = SQLiteDbSession(conn)
    
    print("="*50)
    print("      ASSETFLOW SERVICE FUNCTIONS DEMONSTRATION")
    print("="*50)
    
    # Define IDs from our seed data
    alice_id = "e1111111-1111-1111-1111-111111111111"
    charlie_id = "e3333333-3333-3333-3333-333333333333"
    emma_id = "e5555555-5555-5555-5555-555555555555"
    daniel_id = "e4444444-4444-4444-4444-444444444444"
    
    laptop_1_id = "a1111111-1111-1111-1111-111111111111" # Available
    laptop_2_id = "a2222222-2222-2222-2222-222222222222" # Allocated to Charlie
    conf_room_id = "a3333333-3333-3333-3333-333333333333" # Bookable
    
    # --- DEMO 1: Booking a Shared Resource ---
    print("\n[ACTION] Booking Conference Room for Emma...")
    start_time = datetime.now() + timedelta(days=2, hours=1)
    end_time = start_time + timedelta(hours=1)
    
    success, res, code = validate_and_create_reservation(
        db_session, conf_room_id, emma_id, start_time, end_time, "Daily Standup Meeting"
    )
    print(f"Result (HTTP {code}): {res}")
    
    # Try booking an overlapping reservation
    print("\n[ACTION] Attempting overlapping booking for Alice...")
    success, res_overlap, code_overlap = validate_and_create_reservation(
        db_session, conf_room_id, alice_id, start_time + timedelta(minutes=30), end_time + timedelta(minutes=30), "Important Client Call"
    )
    print(f"Result (HTTP {code_overlap}): {res_overlap}")
    
    # --- DEMO 2: Allocating/Transferring an Asset ---
    print("\n[ACTION] Allocating available laptop (AF-0001) to Emma...")
    success, res, code = handle_asset_allocation_request(db_session, laptop_1_id, emma_id)
    print(f"Result (HTTP {code}): {res}")
    
    # Request transfer for a laptop held by Charlie
    print("\n[ACTION] Requesting transfer for laptop (AF-0002) held by Charlie to Emma...")
    success, res, code = handle_asset_allocation_request(db_session, laptop_2_id, emma_id)
    print(f"Result (HTTP {code}): {res}")
    
    # --- DEMO 3: Auditing an Asset ---
    print("\n[ACTION] Auditor Daniel flags laptop (AF-0001) as DAMAGED...")
    res = record_audit_discrepancy(db_session, laptop_1_id, daniel_id, "DAMAGED", "Spilled coffee on keyboard")
    print(f"Result: {res}")
    
    # Show database status
    cursor = conn.cursor()
    cursor.execute("SELECT asset_tag, status, current_holder_id FROM assets WHERE id = ?", (laptop_1_id,))
    row = cursor.fetchone()
    print(f"\nUpdated Asset Status in DB: Tag={row[0]}, Status={row[1]}, Holder={row[2]}")
    
    conn.close()
    print("\n" + "="*50)
    print("                DEMO COMPLETED!")
    print("="*50)

if __name__ == "__main__":
    run_demo()
