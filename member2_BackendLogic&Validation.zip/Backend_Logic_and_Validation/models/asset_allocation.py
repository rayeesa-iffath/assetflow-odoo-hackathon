from odoo import api, fields, models
from odoo.exceptions import ValidationError, UserError


class AssetFlowAllocation(models.Model):
    _name = 'assetflow.allocation'
    _description = 'Asset Allocation / Transfer'
    _inherit = ['mail.thread']
    _order = 'allocated_on desc'

    asset_id = fields.Many2one('assetflow.asset', required=True, string='Asset', tracking=True)
    employee_id = fields.Many2one('hr.employee', string='Allocated To (Employee)', tracking=True)
    department_id = fields.Many2one('hr.department', string='Allocated To (Department)', tracking=True)

    allocated_on = fields.Datetime(string='Allocated On', default=fields.Datetime.now)
    expected_return_date = fields.Date(string='Expected Return Date', tracking=True)
    actual_return_date = fields.Date(string='Actual Return Date', readonly=True)
    return_condition_notes = fields.Text(string='Condition Check-in Notes')

    active_allocation = fields.Boolean(string='Currently Active', default=True, copy=False)

    state = fields.Selection([
        ('active', 'Active'),
        ('transfer_requested', 'Transfer Requested'),
        ('returned', 'Returned'),
    ], default='active', string='Status', tracking=True)

    is_overdue = fields.Boolean(compute='_compute_is_overdue', store=True)

    # Transfer request fields
    transfer_requested_by = fields.Many2one('res.users', string='Transfer Requested By')
    transfer_to_employee_id = fields.Many2one('hr.employee', string='Transfer To (Employee)')

    @api.depends('expected_return_date', 'active_allocation')
    def _compute_is_overdue(self):
        today = fields.Date.today()
        for rec in self:
            rec.is_overdue = bool(
                rec.active_allocation and rec.expected_return_date and rec.expected_return_date < today
            )

    @api.constrains('asset_id', 'active_allocation')
    def _check_conflict(self):
        """Core conflict rule: an asset can only have ONE active allocation at a time."""
        for rec in self:
            if rec.active_allocation:
                conflict = self.search([
                    ('asset_id', '=', rec.asset_id.id),
                    ('active_allocation', '=', True),
                    ('id', '!=', rec.id),
                ])
                if conflict:
                    holder = conflict[0].employee_id.name or conflict[0].department_id.name or 'someone else'
                    raise ValidationError(
                        f"Asset '{rec.asset_id.display_name_full}' is currently held by {holder}. "
                        f"Please use 'Request Transfer' instead of a new allocation."
                    )

    @api.model_create_multi
    def create(self, vals_list):
        records = super().create(vals_list)
        for rec in records:
            if rec.active_allocation:
                rec.asset_id.write({'status': 'allocated'})
        return records

    def action_request_transfer(self, transfer_to_employee_id):
        """Called from the UI 'Request Transfer' button shown when a conflict is hit."""
        self.ensure_one()
        self.write({
            'state': 'transfer_requested',
            'transfer_requested_by': self.env.user.id,
            'transfer_to_employee_id': transfer_to_employee_id,
        })

    def action_approve_transfer(self):
        """Approved by Asset Manager / Department Head: closes old allocation, opens new one."""
        self.ensure_one()
        if self.state != 'transfer_requested':
            raise UserError("Only allocations with a pending transfer request can be approved.")
        self.write({
            'state': 'returned',
            'active_allocation': False,
            'actual_return_date': fields.Date.today(),
        })
        new_alloc = self.create({
            'asset_id': self.asset_id.id,
            'employee_id': self.transfer_to_employee_id.id,
            'active_allocation': True,
            'state': 'active',
        })
        return new_alloc

    def action_return(self, condition_notes=None):
        """Return flow: mark returned, capture condition notes, asset back to Available."""
        self.ensure_one()
        self.write({
            'state': 'returned',
            'active_allocation': False,
            'actual_return_date': fields.Date.today(),
            'return_condition_notes': condition_notes or self.return_condition_notes,
        })
        self.asset_id.write({'status': 'available'})
