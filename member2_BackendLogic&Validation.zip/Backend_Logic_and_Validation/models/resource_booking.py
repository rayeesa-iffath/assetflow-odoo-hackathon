from odoo import api, fields, models
from odoo.exceptions import ValidationError


class AssetFlowBooking(models.Model):
    _name = 'assetflow.booking'
    _description = 'Resource Booking'
    _inherit = ['mail.thread']
    _order = 'start_time'

    resource_id = fields.Many2one('assetflow.asset', string='Resource', required=True,
                                   domain=[('is_bookable', '=', True)], tracking=True)
    booked_by = fields.Many2one('res.users', string='Booked By', default=lambda self: self.env.user)
    department_id = fields.Many2one('hr.department', string='On Behalf Of Department')

    start_time = fields.Datetime(required=True, tracking=True)
    end_time = fields.Datetime(required=True, tracking=True)

    state = fields.Selection([
        ('upcoming', 'Upcoming'),
        ('ongoing', 'Ongoing'),
        ('completed', 'Completed'),
        ('cancelled', 'Cancelled'),
    ], default='upcoming', string='Status', tracking=True)

    computed_state = fields.Selection([
        ('upcoming', 'Upcoming'),
        ('ongoing', 'Ongoing'),
        ('completed', 'Completed'),
        ('cancelled', 'Cancelled'),
    ], compute='_compute_computed_state', string='Live Status')

    @api.depends('start_time', 'end_time', 'state')
    def _compute_computed_state(self):
        now = fields.Datetime.now()
        for rec in self:
            if rec.state == 'cancelled':
                rec.computed_state = 'cancelled'
            elif rec.end_time and now > rec.end_time:
                rec.computed_state = 'completed'
            elif rec.start_time and rec.end_time and rec.start_time <= now <= rec.end_time:
                rec.computed_state = 'ongoing'
            else:
                rec.computed_state = 'upcoming'

    @api.constrains('resource_id', 'start_time', 'end_time', 'state')
    def _check_overlap(self):
        """Overlap rule: existing.start < new.end AND existing.end > new.start.
        e.g. Room booked 9:00-10:00 -> request for 9:30-10:30 is rejected (overlaps),
        request for 10:00-11:00 is allowed (starts right after, no overlap).
        """
        for rec in self:
            if rec.state == 'cancelled' or not rec.start_time or not rec.end_time:
                continue
            if rec.start_time >= rec.end_time:
                raise ValidationError("End time must be after start time.")
            overlapping = self.search([
                ('resource_id', '=', rec.resource_id.id),
                ('id', '!=', rec.id),
                ('state', '!=', 'cancelled'),
                ('start_time', '<', rec.end_time),
                ('end_time', '>', rec.start_time),
            ])
            if overlapping:
                raise ValidationError(
                    f"'{rec.resource_id.display_name_full}' is already booked from "
                    f"{overlapping[0].start_time} to {overlapping[0].end_time}. "
                    f"Please choose a different time slot."
                )

    def action_cancel(self):
        self.write({'state': 'cancelled'})

    def action_reschedule(self, new_start, new_end):
        self.ensure_one()
        self.write({'start_time': new_start, 'end_time': new_end})
