from odoo import fields, models


class AssetFlowCategory(models.Model):
    _name = 'assetflow.category'
    _description = 'Asset Category'
    _order = 'name'

    name = fields.Char(required=True)
    description = fields.Text()
    # Example of a category-specific optional field (e.g. Electronics warranty)
    default_warranty_months = fields.Integer(
        string='Default Warranty (months)',
        help='Optional: default warranty period for assets in this category (e.g. Electronics).'
    )
    active = fields.Boolean(default=True)

    _sql_constraints = [
        ('name_uniq', 'unique(name)', 'A category with this name already exists.'),
    ]
