from odoo import api, fields, models


class AssetFlowAsset(models.Model):
    _name = 'assetflow.asset'
    _description = 'Asset'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'tag'
    _rec_name = 'display_name_full'

    name = fields.Char(required=True, tracking=True)
    tag = fields.Char(string='Asset Tag', readonly=True, copy=False, default='New')
    category_id = fields.Many2one('assetflow.category', string='Category', required=True, tracking=True)
    serial_no = fields.Char(string='Serial Number')
    qr_code = fields.Char(string='QR Value', compute='_compute_qr_code', store=True,
                           help='Value encoded in the QR / barcode for this asset (defaults to the Asset Tag).')

    acquisition_date = fields.Date(string='Acquisition Date')
    acquisition_cost = fields.Monetary(string='Acquisition Cost',
                                        help='Kept for ranking/reporting only - not linked to accounting.')
    currency_id = fields.Many2one('res.currency', default=lambda self: self.env.company.currency_id)

    condition = fields.Selection([
        ('good', 'Good'),
        ('fair', 'Fair'),
        ('poor', 'Poor'),
    ], default='good', string='Condition', tracking=True)

    location = fields.Char(string='Location')
    department_id = fields.Many2one('hr.department', string='Department')

    is_bookable = fields.Boolean(string='Shared / Bookable Resource',
                                  help='Check this if the asset is a shared resource that can be booked '
                                       '(e.g. meeting room, vehicle, projector) rather than allocated to one person.')

    image_1920 = fields.Image(string='Photo', max_width=1920, max_height=1920)
    document_ids = fields.Many2many('ir.attachment', string='Documents')

    status = fields.Selection([
        ('available', 'Available'),
        ('allocated', 'Allocated'),
        ('reserved', 'Reserved'),
        ('maintenance', 'Under Maintenance'),
        ('lost', 'Lost'),
        ('retired', 'Retired'),
        ('disposed', 'Disposed'),
    ], default='available', required=True, tracking=True, string='Status')

    active = fields.Boolean(default=True)

    allocation_ids = fields.One2many('assetflow.allocation', 'asset_id', string='Allocation History')
    booking_ids = fields.One2many('assetflow.booking', 'resource_id', string='Booking History')

    current_allocation_id = fields.Many2one(
        'assetflow.allocation', string='Current Allocation',
        compute='_compute_current_allocation', store=False
    )
    current_holder_name = fields.Char(compute='_compute_current_allocation', store=False)

    display_name_full = fields.Char(compute='_compute_display_name_full', store=True)

    @api.depends('tag', 'name')
    def _compute_display_name_full(self):
        for rec in self:
            rec.display_name_full = f"[{rec.tag}] {rec.name}" if rec.tag and rec.tag != 'New' else rec.name

    @api.depends('tag')
    def _compute_qr_code(self):
        for rec in self:
            rec.qr_code = rec.tag or 'New'

    def _compute_current_allocation(self):
        for rec in self:
            active_alloc = self.env['assetflow.allocation'].search([
                ('asset_id', '=', rec.id),
                ('active_allocation', '=', True),
            ], limit=1)
            rec.current_allocation_id = active_alloc
            rec.current_holder_name = active_alloc.employee_id.name if active_alloc.employee_id else (
                active_alloc.department_id.name if active_alloc.department_id else False
            )

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get('tag', 'New') == 'New':
                vals['tag'] = self.env['ir.sequence'].next_by_code('assetflow.asset') or 'New'
        records = super().create(vals_list)
        return records

    def name_search(self, name='', args=None, operator='ilike', limit=100):
        """Allow search box to match on tag, serial number, or name (QR/search screen requirement)."""
        args = args or []
        if name:
            domain = ['|', '|',
                      ('tag', operator, name),
                      ('serial_no', operator, name),
                      ('name', operator, name)]
            recs = self.search(domain + args, limit=limit)
            return recs.name_get()
        return super().name_search(name, args, operator, limit)

    # ---- Lifecycle transitions ----
    def action_set_available(self):
        self.write({'status': 'available'})

    def action_set_maintenance(self):
        self.write({'status': 'maintenance'})

    def action_set_lost(self):
        self.write({'status': 'lost'})

    def action_set_retired(self):
        self.write({'status': 'retired'})

    def action_set_disposed(self):
        self.write({'status': 'disposed'})
