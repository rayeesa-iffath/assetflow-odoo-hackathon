import sqlite3
import uuid
import sys
import os
from datetime import datetime

from services.reservation_service import validate_and_create_reservation
from services.asset_allocation_service import handle_asset_allocation_request
from services.audit_service import record_audit_discrepancy

# Custom Row wrapper for attribute access (mocking SQLAlchemy row objects)
class SQLiteRowWrapper:
    def __init__(self, description, row_tuple):
        self._keys = [col[0] for col in description] if description else []
        self._values = row_tuple if row_tuple else []
        
    def __getattr__(self, name):
        if name in self._keys:
            idx = self._keys.index(name)
            return self._values[idx]
        raise AttributeError(f"Row has no attribute '{name}'")
        
    def __getitem__(self, index):
        return self._values[index]

class SQLiteQueryResult:
    def __init__(self, cursor):
        self.cursor = cursor
        
    def fetchone(self):
        row = self.cursor.fetchone()
        if row is None:
            return None
        return SQLiteRowWrapper(self.cursor.description, row)

class SQLiteDbSession:
    def __init__(self, conn):
        self.conn = conn
        
    def query(self, query_str, params=None):
        cursor = self.conn.cursor()
        cursor.execute(query_str, params or {})
        return SQLiteQueryResult(cursor)
        
    def execute(self, query_str, params=None):
        cursor = self.conn.cursor()
        cursor.execute(query_str, params or {})
        return SQLiteQueryResult(cursor)
        
    def commit(self):
        self.conn.commit()

def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def print_header(title):
    print("="*60)
    print(f" {title.center(58)} ")
    print("="*60)

def main_menu(db_session, conn):
    while True:
        clear_screen()
        print_header("AssetFlow Interactive CLI Manager")
        print("1. View Assets Directory")
        print("2. Add New Asset")
        print("3. View Employees / Users")
        print("4. Add New Employee")
        print("5. Create Resource Booking (Reservation)")
        print("6. Request Asset Allocation / Transfer")
        print("7. Record Audit Discrepancy")
        print("8. View Bookings & Transfers Logs")
        print("9. Exit")
        print("="*60)
        
        choice = input("Enter your choice (1-9): ").strip()
        
        if choice == '1':
            view_assets(conn)
        elif choice == '2':
            add_asset(conn)
        elif choice == '3':
            view_employees(conn)
        elif choice == '4':
            add_employee(conn)
        elif choice == '5':
            book_resource(db_session, conn)
        elif choice == '6':
            allocate_asset(db_session, conn)
        elif choice == '7':
            audit_asset(db_session, conn)
        elif choice == '8':
            view_logs(conn)
        elif choice == '9':
            print("\nExiting. Thank you!")
            break
        else:
            input("\nInvalid choice. Press Enter to try again...")

def view_assets(conn):
    clear_screen()
    print_header("Assets Directory")
    cursor = conn.cursor()
    cursor.execute("""
        SELECT a.id, a.asset_tag, a.status, a.is_bookable, c.name, e.name 
        FROM assets a
        LEFT JOIN asset_categories c ON a.category_id = c.id
        LEFT JOIN employees e ON a.current_holder_id = e.id
    """)
    rows = cursor.fetchall()
    
    if not rows:
        print("No assets found in database.")
    else:
        print(f"{'Asset Tag':<12} | {'Category':<20} | {'Status':<17} | {'Is Bookable':<11} | {'Current Holder':<20}")
        print("-" * 88)
        for row in rows:
            bookable = "Yes" if row[3] else "No"
            holder = row[5] if row[5] else "None (Available)"
            print(f"{row[1]:<12} | {row[4]:<20} | {row[2]:<17} | {bookable:<11} | {holder:<20}")
            
    input("\nPress Enter to return to menu...")

def view_employees(conn):
    clear_screen()
    print_header("Employees Directory")
    cursor = conn.cursor()
    cursor.execute("SELECT e.id, e.name, e.email, e.role, d.name FROM employees e LEFT JOIN departments d ON e.department_id = d.id")
    rows = cursor.fetchall()
    
    if not rows:
        print("No employees found.")
    else:
        print(f"{'Employee ID (First 8)':<21} | {'Name':<18} | {'Email':<25} | {'Role':<15}")
        print("-" * 85)
        for row in rows:
            print(f"{row[0][:8]:<21} | {row[1]:<18} | {row[2]:<25} | {row[3]:<15}")
            
    input("\nPress Enter to return to menu...")

def add_employee(conn):
    clear_screen()
    print_header("Register New Employee")
    name = input("Enter Name: ").strip()
    email = input("Enter Email: ").strip()
    role = input("Enter Role (ADMIN / EMPLOYEE / AUDITOR / DEPARTMENT_HEAD): ").strip().upper()
    
    if role not in ['ADMIN', 'EMPLOYEE', 'AUDITOR', 'DEPARTMENT_HEAD']:
        print("Error: Invalid role. Must be one of ADMIN, EMPLOYEE, AUDITOR, DEPARTMENT_HEAD.")
        input("\nPress Enter to return...")
        return
        
    cursor = conn.cursor()
    # Fetch a department to link
    cursor.execute("SELECT id, name FROM departments LIMIT 1")
    dept = cursor.fetchone()
    dept_id = dept[0] if dept else None
    
    emp_id = str(uuid.uuid4())
    try:
        cursor.execute(
            "INSERT INTO employees (id, name, email, password_hash, role, department_id) VALUES (?, ?, ?, ?, ?, ?)",
            (emp_id, name, email, "pbkdf2_placeholder_hash", role, dept_id)
        )
        conn.commit()
        print(f"\nSUCCESS: Employee '{name}' registered successfully with ID: {emp_id}")
    except sqlite3.IntegrityError as e:
        print(f"\nError: Could not insert employee. Email might already exist. ({e})")
        
    input("\nPress Enter to return to menu...")

def add_asset(conn):
    clear_screen()
    print_header("Register New Asset")
    
    cursor = conn.cursor()
    cursor.execute("SELECT id, name FROM asset_categories")
    categories = cursor.fetchall()
    
    if not categories:
        print("Error: No categories found. Please create one in categories table first.")
        input("\nPress Enter to return...")
        return
        
    print("Available Categories:")
    for idx, cat in enumerate(categories):
        print(f"  {idx + 1}. {cat[1]} (ID: {cat[0]})")
        
    cat_choice = input("Select Category (number): ").strip()
    try:
        cat_idx = int(cat_choice) - 1
        category_id = categories[cat_idx][0]
    except (ValueError, IndexError):
        print("Invalid category choice.")
        input("\nPress Enter to return...")
        return
        
    name = input("Enter Asset Name: ").strip()
    tag = input("Enter Asset Tag (e.g. AF-0005): ").strip()
    is_bookable_str = input("Is this a Shared / Bookable resource? (yes/no): ").strip().lower()
    is_bookable = True if is_bookable_str in ['y', 'yes', 'true'] else False
    
    asset_id = str(uuid.uuid4())
    try:
        cursor.execute(
            "INSERT INTO assets (id, asset_tag, category_id, current_holder_id, assigned_department_id, status, is_bookable) VALUES (?, ?, ?, NULL, NULL, 'AVAILABLE', ?)",
            (asset_id, tag, category_id, is_bookable)
        )
        # Also create a default department mapping if possible
        cursor.execute("SELECT id FROM departments LIMIT 1")
        dept = cursor.fetchone()
        if dept:
            cursor.execute("UPDATE assets SET assigned_department_id = ? WHERE id = ?", (dept[0], asset_id))
            
        conn.commit()
        print(f"\nSUCCESS: Asset '{name}' [{tag}] added successfully!")
    except sqlite3.IntegrityError as e:
        print(f"\nError: Could not insert asset. Tag might already be taken. ({e})")
        
    input("\nPress Enter to return to menu...")

def book_resource(db_session, conn):
    clear_screen()
    print_header("Book a Shared Resource")
    
    cursor = conn.cursor()
    cursor.execute("SELECT id, asset_tag FROM assets WHERE is_bookable = 1")
    bookable_assets = cursor.fetchall()
    
    if not bookable_assets:
        print("No bookable resources registered.")
        input("\nPress Enter to return...")
        return
        
    print("Available Bookable Assets:")
    for idx, asset in enumerate(bookable_assets):
        print(f"  {idx + 1}. {asset[1]} (ID: {asset[0]})")
        
    asset_choice = input("Select Asset (number): ").strip()
    try:
        asset_idx = int(asset_choice) - 1
        asset_id = bookable_assets[asset_idx][0]
    except (ValueError, IndexError):
        print("Invalid choice.")
        input("\nPress Enter to return...")
        return
        
    cursor.execute("SELECT id, name FROM employees")
    employees = cursor.fetchall()
    print("\nEmployees list:")
    for idx, emp in enumerate(employees):
        print(f"  {idx + 1}. {emp[1]} (ID: {emp[0][:8]}...)")
        
    emp_choice = input("Select Booking Employee (number): ").strip()
    try:
        emp_idx = int(emp_choice) - 1
        employee_id = employees[emp_idx][0]
    except (ValueError, IndexError):
        print("Invalid choice.")
        input("\nPress Enter to return...")
        return
        
    start_str = input("Enter Start Time (format YYYY-MM-DD HH:MM:SS): ").strip()
    end_str = input("Enter End Time (format YYYY-MM-DD HH:MM:SS): ").strip()
    purpose = input("Enter Purpose: ").strip()
    
    try:
        start_dt = datetime.strptime(start_str, "%Y-%m-%d %H:%M:%S")
        end_dt = datetime.strptime(end_str, "%Y-%m-%d %H:%M:%S")
    except ValueError as e:
        print(f"Invalid date format: {e}")
        input("\nPress Enter to return...")
        return
        
    # Run service
    success, res, code = validate_and_create_reservation(
        db_session, asset_id, employee_id, start_dt, end_dt, purpose
    )
    
    print("\n" + "="*40)
    print(f"Booking Status: HTTP {code}")
    print(f"Payload: {res}")
    print("="*40)
    
    input("\nPress Enter to return to menu...")

def allocate_asset(db_session, conn):
    clear_screen()
    print_header("Allocate / Transfer Asset")
    
    cursor = conn.cursor()
    cursor.execute("SELECT id, asset_tag, status FROM assets WHERE is_bookable = 0")
    allocatable_assets = cursor.fetchall()
    
    if not allocatable_assets:
        print("No allocatable assets registered.")
        input("\nPress Enter to return...")
        return
        
    print("Allocatable Assets:")
    for idx, asset in enumerate(allocatable_assets):
        print(f"  {idx + 1}. {asset[1]} (Status: {asset[2]})")
        
    asset_choice = input("Select Asset (number): ").strip()
    try:
        asset_idx = int(asset_choice) - 1
        asset_id = allocatable_assets[asset_idx][0]
    except (ValueError, IndexError):
        print("Invalid choice.")
        input("\nPress Enter to return...")
        return
        
    cursor.execute("SELECT id, name FROM employees")
    employees = cursor.fetchall()
    print("\nEmployees list:")
    for idx, emp in enumerate(employees):
        print(f"  {idx + 1}. {emp[1]} (ID: {emp[0][:8]}...)")
        
    emp_choice = input("Select Requesting Employee (number): ").strip()
    try:
        emp_idx = int(emp_choice) - 1
        employee_id = employees[emp_idx][0]
    except (ValueError, IndexError):
        print("Invalid choice.")
        input("\nPress Enter to return...")
        return
        
    # Run service
    success, res, code = handle_asset_allocation_request(db_session, asset_id, employee_id)
    
    print("\n" + "="*40)
    print(f"Allocation Status: HTTP {code}")
    print(f"Payload: {res}")
    print("="*40)
    
    input("\nPress Enter to return to menu...")

def audit_asset(db_session, conn):
    clear_screen()
    print_header("Audit / Record Discrepancy")
    
    cursor = conn.cursor()
    cursor.execute("SELECT id, asset_tag, status FROM assets")
    assets = cursor.fetchall()
    
    print("Assets:")
    for idx, asset in enumerate(assets):
        print(f"  {idx + 1}. {asset[1]} (Current Status: {asset[2]})")
        
    asset_choice = input("Select Asset (number): ").strip()
    try:
        asset_idx = int(asset_choice) - 1
        asset_id = assets[asset_idx][0]
    except (ValueError, IndexError):
        print("Invalid choice.")
        input("\nPress Enter to return...")
        return
        
    cursor.execute("SELECT id, name FROM employees WHERE role = 'AUDITOR'")
    auditors = cursor.fetchall()
    
    if not auditors:
        print("No employee with AUDITOR role found. Creating discrepancy will fail.")
        input("\nPress Enter to return...")
        return
        
    print("\nAuditors List:")
    for idx, aud in enumerate(auditors):
        print(f"  {idx + 1}. {aud[1]}")
        
    aud_choice = input("Select Auditor (number): ").strip()
    try:
        aud_idx = int(aud_choice) - 1
        auditor_id = auditors[aud_idx][0]
    except (ValueError, IndexError):
        print("Invalid choice.")
        input("\nPress Enter to return...")
        return
        
    print("\nDiscrepancy Status Flags:")
    print("  1. MISSING (flags asset as LOST)")
    print("  2. DAMAGED (flags asset as UNDER_MAINTENANCE)")
    print("  3. UNAUTHORIZED_HOLDER (flags asset as ALLOCATED)")
    
    flag_choice = input("Select Discrepancy Flag (1-3): ").strip()
    flag_map = {'1': 'MISSING', '2': 'DAMAGED', '3': 'UNAUTHORIZED_HOLDER'}
    status_flag = flag_map.get(flag_choice)
    
    if not status_flag:
        print("Invalid flag choice.")
        input("\nPress Enter to return...")
        return
        
    notes = input("Enter Audit Notes: ").strip()
    
    # Run service
    res = record_audit_discrepancy(db_session, asset_id, auditor_id, status_flag, notes)
    
    print("\n" + "="*40)
    print(f"Audit Status: Logged Successfully")
    print(f"Payload: {res}")
    print("="*40)
    
    input("\nPress Enter to return to menu...")

def view_logs(conn):
    clear_screen()
    print_header("Bookings, Transfers & Audit Logs")
    cursor = conn.cursor()
    
    # Bookings
    print("\n--- ACTIVE BOOKINGS ---")
    cursor.execute("""
        SELECT a.asset_tag, e.name, b.start_time, b.end_time, b.purpose, b.status 
        FROM asset_reservations b
        JOIN assets a ON b.asset_id = a.id
        JOIN employees e ON b.reserved_by_id = e.id
    """)
    bookings = cursor.fetchall()
    if not bookings:
        print("No reservations booked.")
    else:
        for b in bookings:
            print(f"Asset: {b[0]} | Reserved By: {b[1]} | From: {b[2]} To: {b[3]} | Status: {b[5]} | Purpose: {b[4]}")
            
    # Transfers
    print("\n--- TRANSFER REQUESTS ---")
    cursor.execute("""
        SELECT a.asset_tag, f.name, t.name, tr.status, tr.created_at 
        FROM asset_transfers tr
        JOIN assets a ON tr.asset_id = a.id
        JOIN employees f ON tr.from_user_id = f.id
        JOIN employees t ON tr.to_user_id = t.id
    """)
    transfers = cursor.fetchall()
    if not transfers:
        print("No transfer requests found.")
    else:
        for t in transfers:
            print(f"Asset: {t[0]} | From: {t[1]} -> To: {t[2]} | Status: {t[3]} (Created: {t[4]})")
            
    # Audit logs
    print("\n--- AUDIT LOGS ---")
    cursor.execute("""
        SELECT a.asset_tag, e.name, au.status_flag, au.notes, au.created_at 
        FROM audit_logs au
        JOIN assets a ON au.asset_id = a.id
        JOIN employees e ON au.auditor_id = e.id
    """)
    audits = cursor.fetchall()
    if not audits:
        print("No audit discrepancy logs found.")
    else:
        for au in audits:
            print(f"Asset: {au[0]} | Auditor: {au[1]} | Flag: {au[2]} | Notes: {au[3]} (Date: {au[4]})")
            
    input("\nPress Enter to return to menu...")

if __name__ == "__main__":
    db_file = "assetflow.db"
    if not os.path.exists(db_file):
        print(f"Error: {db_file} not found. Please run 'python init_db.py' first.")
        sys.exit(1)
        
    conn = sqlite3.connect(db_file)
    conn.execute("PRAGMA foreign_keys = ON;")
    # Custom PostgreSQL functions registered for SQLite
    conn.create_function("GENERATE_UUID", 0, lambda: str(uuid.uuid4()))
    conn.create_function("NOW", 0, lambda: datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    
    db_session = SQLiteDbSession(conn)
    main_menu(db_session, conn)
    conn.close()
